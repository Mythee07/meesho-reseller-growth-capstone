import csv, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "part2_engine"))
from growth_engine import validate_feed, mom_growth, is_flagged

def _read_feed(path):
    with open(path, newline="", encoding="utf-8") as f:
        return [{"month": r["month"], "category": r["category"], "revenue": float(r["revenue"]), "n_orders": int(r["n_orders"])}
                for r in csv.DictReader(f)]

def fill_narrative(category, previous_revenue, current_revenue, mom_pct, month, prev_month):
    return (f"Context: {category} revenue is monitored for {month} vs {prev_month}. "
            f"Insight — fact: {category} changed {mom_pct}% month-on-month. "
            f"Implication — hypothesis: check reseller/region concentration and operational drivers before changing support.")

def run(month: str, previous_month_csv: str, current_month_csv: str) -> dict:
    valid, errors = validate_feed(current_month_csv)
    if not valid:
        return {"run_month": month, "validation_status": "invalid", "validation_errors": errors,
                "flagged_categories": [], "suppressed_categories": [], "escalated_categories": [],
                "action_taken": "hard_stop"}

    previous = {r["category"]: r["revenue"] for r in _read_feed(previous_month_csv)}
    current = {r["category"]: r["revenue"] for r in _read_feed(current_month_csv)}
    flagged, escalated = [], []
    for category, current_revenue in current.items():
        if category not in previous:
            continue
        previous_revenue = previous[category]
        pct = mom_growth(previous_revenue, current_revenue)
        status = is_flagged(pct)
        if status == "flagged":
            flagged.append({"category": category, "mom_pct": pct, "previous_revenue": previous_revenue,
                            "current_revenue": current_revenue, "_abs": abs(pct)})
        elif status == "escalate_exact_boundary":
            escalated.append(category)

    flagged.sort(key=lambda x: x["_abs"], reverse=True)
    top3, suppressed = flagged[:3], [x["category"] for x in flagged[3:]]
    prev_month = Path(previous_month_csv).stem.replace("monthly_category_revenue_", "")
    output = []
    for x in top3:
        output.append({"category": x["category"], "mom_pct": x["mom_pct"],
                       "previous_revenue": x["previous_revenue"], "current_revenue": x["current_revenue"],
                       "drafted": True,
                       "message": fill_narrative(x["category"], x["previous_revenue"], x["current_revenue"],
                                                 x["mom_pct"], month, prev_month)})
    return {"run_month": month, "validation_status": "valid", "validation_errors": [],
            "flagged_categories": output, "suppressed_categories": suppressed,
            "escalated_categories": escalated, "action_taken": "drafted_and_held_for_approval"}

if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("Usage: python part4_agent/mock_agent_runner.py RUN_MONTH PREVIOUS_CSV CURRENT_CSV")
    print(json.dumps(run(sys.argv[1], sys.argv[2], sys.argv[3]), indent=2))
