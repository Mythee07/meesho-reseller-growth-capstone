# Agent Specification

## Goal
Keep Meesho category managers informed of any category whose month-on-month revenue moves beyond the 8% threshold, with a human approving every message before it goes out.

## Tools
`validate_feed`, `mom_growth`, `is_flagged` from Part 2; the deterministic template-fill function following Part 3's prompt pack.

## Memory/State
Remember the previous month's verified revenue per category so the next run can compute MoM growth. The current validated feed becomes the next run's state only when explicitly stored.

## Planner
1. Load the monthly revenue feed and run `validate_feed`.
2. If invalid, Hard Stop and report errors.
3. If valid, compute `mom_growth` for every category against the previous month.
4. Run `is_flagged` on every category.
5. Sort flagged categories by `abs(mom_pct)` descending.
6. Draft at most the top 3 by magnitude.
7. Log remaining flagged categories as suppressed for manual review.
7b. Separately log `escalate_exact_boundary` categories in `escalated_categories`, with no draft.
8. Emit one structured JSON object per run.

## Feedback Loop
No message is auto-sent. Drafts are held for human approval.

## Guardrails
- **Input:** `validate_feed` must pass before anything else runs.
- **Action:** no message is ever auto-sent; only drafted and held.
- **Output:** every number in a drafted message must trace to Part 1/Part 2.

## Success and error stopping conditions
- **Success:** drafts are produced, or zero drafts if nothing crosses the threshold, with traceable numbers.
- **Error:** validation is false → **Hard Stop**, errors surfaced, no MoM computation.

## Agent-level Given-When-Then specifications
1. **GIVEN** April→May Ethnic Wear moves 104520.77 to 185107.61, **WHEN** evaluated, **THEN** 77.1 and `"flagged"`.
2. **GIVEN** May→June Beauty & Personal Care moves 35542.11 to 37559.07, **WHEN** evaluated, **THEN** 5.67 and `"not_flagged"`.
3. **GIVEN** 100000 to 108000, **WHEN** evaluated, **THEN** 8.0 and `"escalate_exact_boundary"`.
4. **GIVEN** the corrupted feed, **WHEN** validated, **THEN** exactly the three validation errors occur and the run Hard Stops.
