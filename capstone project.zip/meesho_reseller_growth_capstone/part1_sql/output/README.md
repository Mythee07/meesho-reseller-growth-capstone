# Part 1 SQL outputs

The zero-order demonstration is intentionally separate. For RS024, a LEFT JOIN produces one all-NULL joined row, so `COUNT(*) = 1` while `COUNT(order_id) = 0`. Therefore `COUNT(*)` cannot be used to detect a zero-match LEFT JOIN; use `COUNT(o.order_id)` or `WHERE o.order_id IS NULL`.
