-- Part 1 — SQL Business Query Engine
SELECT month, category, ROUND(SUM(quantity * unit_price), 2) AS revenue, COUNT(*) AS n_orders
FROM orders
GROUP BY month, category
ORDER BY CASE month WHEN 'April' THEN 1 WHEN 'May' THEN 2 WHEN 'June' THEN 3 END,
         CASE category WHEN 'Ethnic Wear' THEN 1 WHEN 'Western Wear' THEN 2
                       WHEN 'Kids Wear' THEN 3 WHEN 'Home & Kitchen' THEN 4
                       WHEN 'Beauty & Personal Care' THEN 5 END;

SELECT r.region, ROUND(SUM(o.quantity * o.unit_price), 2) AS revenue, COUNT(o.order_id) AS n_orders
FROM orders o JOIN resellers r ON o.reseller_id = r.reseller_id
GROUP BY r.region ORDER BY revenue DESC;

SELECT r.reseller_id, r.reseller_name, ROUND(SUM(o.quantity * o.unit_price), 2) AS total_spend
FROM orders o JOIN resellers r ON o.reseller_id = r.reseller_id
GROUP BY r.reseller_id, r.reseller_name
HAVING total_spend > 50000
ORDER BY total_spend DESC LIMIT 5;

SELECT r.reseller_id, r.reseller_name, r.region
FROM resellers r LEFT JOIN orders o ON r.reseller_id = o.reseller_id
WHERE o.order_id IS NULL;

SELECT r.reseller_id, COUNT(*) AS row_count, COUNT(o.order_id) AS matched_order_count
FROM resellers r LEFT JOIN orders o ON r.reseller_id = o.reseller_id
WHERE r.reseller_id = 'RS024'
GROUP BY r.reseller_id;

SELECT ROUND(SUM(quantity * unit_price) / COUNT(*), 2) AS aov
FROM orders WHERE month = 'June' AND status = 'Delivered';
