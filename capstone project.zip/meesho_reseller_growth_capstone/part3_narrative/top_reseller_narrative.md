# Masked Top-Reseller Narrative

- West — RS019 / ALIAS-19 — verified total spend: 75295.09.
- West — RS022 / ALIAS-22 — verified total spend: 73882.33.
- South — RS012 / ALIAS-12 — verified total spend: 69936.46.
- North — RS006 / ALIAS-06 — verified total spend: 64238.97.
- North — RS005 / ALIAS-05 — verified total spend: 61825.02.
