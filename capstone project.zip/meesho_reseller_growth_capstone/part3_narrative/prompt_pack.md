# Reusable Prompt Pack

## Trigger
Start when a category's `is_flagged` result is exactly `"flagged"`. Exact-boundary results are held for human review.

## Input list
`{category}`, `{previous_revenue}`, `{current_revenue}`, `{mom_pct}`, `{month}`, `{prev_month}`.

## Prompt
Using only the supplied placeholders, write a stakeholder update in **Context → Insight → Implication** structure. State the supplied MoM percentage as a **fact**. If a cause is proposed that the data does not prove, label it a **hypothesis**. Never state a number that is not one of the supplied placeholders. Never expose a raw reseller name; use a coded alias only.

## Checklist
1. Every number matches a supplied placeholder exactly.
2. The MoM percentage is labeled as a fact.
3. Any unproven cause is labeled as a hypothesis.
4. The recommendation is specific and actionable.
5. The comparison period is named explicitly.
6. Any reseller is referenced only by coded alias.
