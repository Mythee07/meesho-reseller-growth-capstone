from masking import alias_for, assert_no_raw_names_leak
assert alias_for("RS019") == "ALIAS-19"
assert assert_no_raw_names_leak("West — ALIAS-19", ["Mumbai Reseller 1"]) is True
assert assert_no_raw_names_leak("West — Mumbai Reseller 1", ["Mumbai Reseller 1"]) is False
print("All masking tests passed.")
