# Worked Narrative Report

## May — Ethnic Wear

**Context:** This monitors Ethnic Wear revenue from April to May.

**Insight — fact:** Ethnic Wear revenue increased **77.1%** month-on-month from April to May. The supplied SQL feed reports April revenue **104520.77** and May revenue **185107.61**.

**Implication — hypothesis:** Check whether the May movement was concentrated in a small number of resellers or regions and whether the category mix changed materially before increasing inventory or promotional support. The data alone does not prove the cause, so the causal explanation is a **hypothesis**.

### Refinement self-score
- **Specificity — pass:** Exact category, months, revenues, and 77.1% are stated.
- **Audience fit — pass:** The recommendation is framed for a regional manager.
- **Completeness — pass:** Context, Insight, and Implication are present.
- **Actionability — pass:** The next investigation is explicitly named.

## June — Ethnic Wear

**Context:** This monitors Ethnic Wear revenue from May to June.

**Insight — fact:** Ethnic Wear revenue decreased **-58.74%** month-on-month from May to June. The supplied SQL feed reports May revenue **185107.61** and June revenue **76371.53**.

**Implication — hypothesis:** Identify which reseller/region combinations account for the decline and verify whether product availability or promotional activity changed. Any explanation of why the decline occurred remains a **hypothesis** until those checks are completed.

### Refinement self-score
- **Specificity — pass:** Exact category, months, revenues, and -58.74% are stated.
- **Audience fit — pass:** The update tells a regional manager what to investigate.
- **Completeness — pass:** Context, Insight, and Implication are present.
- **Actionability — pass:** The next step names concrete reseller/region and operational checks.

## Chart-choice justification

### 1. Which month had the highest total revenue?
**Vertical bar chart.** This is a univariate comparison of revenue across months. Bars make the highest month immediately visible; the y-axis should start at zero, there should be no 3D effect, and the message should be clear within 10 seconds. April = INR 419417.43, May = INR 444594.25, June = INR 398055.24, so May is highest.

### 2. What percentage share does Ethnic Wear represent of April's total revenue?
**Pie/donut chart.** This is a part-to-whole composition question, so a simple part-to-whole chart communicates the 24.92% share quickly. Avoid 3D and label the share directly. Ethnic Wear is INR 104520.77 of April's INR 419417.43.

### 3. How do the four regions compare on total revenue?
**Horizontal bar chart.** This is a univariate comparison of revenue across four categories (regions). Start the y-axis at zero, avoid 3D, and omit a legend because there is only one series; direct bar lengths make the comparison clear within 10 seconds.
