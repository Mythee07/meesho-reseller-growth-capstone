# Meesho Reseller Growth & Alert Intelligence Pipeline

This repository implements the four-part capstone as one integrated, deterministic, offline pipeline.

## Workflow
**Part 1 SQL → Part 2 Guardrails/Growth → Part 3 Narrative/Masking → Part 4 Agent Runner**

- Part 1 computes verified business numbers first.
- Part 2 validates those numbers and makes “significant change” testable.
- Part 3 turns only verified numbers into a stakeholder narrative.
- Part 4 orchestrates intake → validation → computation → ranking → capped drafting → human approval hold.

## Zero-key requirement
The full project works with zero API keys and no paid/account-gated services. The narrative path is deterministic template-fill; no real LLM call is required.

## Run order

### 1. Generate data
```bash
python data/generate_dataset.py
```

Creates 24 resellers, 900 orders (300 each for April, May and June 2026), and `data/meesho_reseller.db`.

### 2. Part 1
Review/run `part1_sql/queries.sql` against `data/meesho_reseller.db`. Outputs are under `part1_sql/output/`.

Required checks:
- Grand total revenue = INR 1262066.92
- June Delivered AOV = INR 1267.69
- Zero-order reseller = RS024
- RS024 LEFT JOIN demonstration: `COUNT(*) = 1`, `COUNT(order_id) = 0`

### 3. Part 2
```bash
cd part2_engine
python test_growth_engine.py
cd ..
```

### 4. Part 3
```bash
cd part3_narrative
python test_masking.py
cd ..
```

### 5. Part 4
May:
```bash
python part4_agent/mock_agent_runner.py May part2_engine/fixtures/monthly_category_revenue_april.csv part2_engine/fixtures/monthly_category_revenue_may.csv
```

June:
```bash
python part4_agent/mock_agent_runner.py June part2_engine/fixtures/monthly_category_revenue_may.csv part2_engine/fixtures/monthly_category_revenue_june.csv
```

Corrupted-feed hard stop:
```bash
python part4_agent/mock_agent_runner.py July part2_engine/fixtures/monthly_category_revenue_june.csv part2_engine/fixtures/corrupted_feed.csv
```

## Expected Part 4 results
### May
Drafted in magnitude order: Ethnic Wear 77.1%, Western Wear -23.6%, Kids Wear -23.48%.
Suppressed: Beauty & Personal Care and Home & Kitchen.
Escalated: none.

### June
Drafted: Ethnic Wear -58.74%, Home & Kitchen 42.59%, Kids Wear 23.9%.
Suppressed: Western Wear.
Beauty & Personal Care 5.67% appears in neither flagged nor suppressed.
Escalated: none.

### Corrupted feed
Validation fails with exactly the three specified errors. Action is `hard_stop`; no MoM computation occurs.

## Repository contents
```text
data/generate_dataset.py
data/resellers.csv
data/orders.csv
data/meesho_reseller.db
part1_sql/queries.sql
part1_sql/output/*.csv
part2_engine/growth_engine.py
part2_engine/test_growth_engine.py
part2_engine/fixtures/*.csv
part3_narrative/prompt_pack.md
part3_narrative/narrative_report.md
part3_narrative/masking.py
part4_agent/agent_spec.md
part4_agent/mock_agent_runner.py
README.md
```

## Academic integrity
The course brief permits consultation of official Python standard-library documentation. This project uses standard-library modules including `csv`, `sqlite3`, `json`, `pathlib`, and `sys`. No external data or paid service is required.

## Submission
The course brief says the graded deliverable is **one public GitHub repository link**. Push this repository to GitHub, make it public, and submit only that repository URL.
