from growth_engine import mom_growth, is_flagged, validate_feed
from pathlib import Path

# GIVEN April→May Ethnic Wear
x = mom_growth(104520.77, 185107.61)
assert x == 77.1
assert is_flagged(x) == "flagged"

# GIVEN May→June Beauty & Personal Care
x = mom_growth(35542.11, 37559.07)
assert x == 5.67
assert is_flagged(x) == "not_flagged"

# GIVEN exact threshold boundary
x = mom_growth(100000, 108000)
assert x == 8.0
assert is_flagged(x) == "escalate_exact_boundary"

# GIVEN corrupted feed
fixture = Path(__file__).parent / "fixtures" / "corrupted_feed.csv"
ok, errors = validate_feed(str(fixture))
expected = [
    "line 3: negative revenue (-4200.0) for category=Western Wear",
    "line 4: missing category (month=July)",
    "line 6: missing revenue (category=Home & Kitchen)",
]
assert ok is False
assert errors == expected

# Valid Part 1 feed
valid = Path(__file__).parent / "fixtures" / "monthly_category_revenue.csv"
ok, errors = validate_feed(str(valid))
assert ok is True and errors == []

print("All Part 2 tests passed.")
